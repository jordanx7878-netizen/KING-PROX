package com.king.calibrador;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    static final int REQ = 1001;
    LinearLayout root, content;
    TextView shizukuStatus, statusText, resText;
    Button mainButton;
    SeekBar xSeek, ySeek;
    TextView xVal, yVal;
    SharedPreferences prefs;

    int purple = Color.rgb(123,44,255);
    int bg = Color.rgb(5,5,8);
    int panel = Color.rgb(16,16,24);
    int white = Color.WHITE;
    int muted = Color.rgb(169,162,183);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("king", MODE_PRIVATE);
        buildUi();
        updateShizuku();
    }

    GradientDrawable bg(int color, float radius, int strokeColor, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(radius);
        if (stroke > 0) g.setStroke(stroke, strokeColor);
        return g;
    }
    TextView tv(String s, float size, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(16,8,16,8); return t;
    }
    Button btn(String s) {
        Button b = new Button(this); b.setText(s); b.setTextColor(white);
        b.setTextSize(14); b.setAllCaps(false);
        b.setBackground(bg(purple, 28, purple, 1));
        b.setPadding(16,4,16,4);
        return b;
    }
    LinearLayout card() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(14,14,14,14); l.setBackground(bg(panel, 24, Color.rgb(48,38,75), 1));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.setMargins(0,8,0,8);
        l.setLayoutParams(p); return l;
    }
    void buildUi() {
        ScrollView sv = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(16,12,16,24); root.setBackgroundColor(bg);
        sv.addView(root);
        setContentView(sv);

        TextView title = tv("♛  KING CALIBRADOR", 22, white);
        title.setTypeface(null, 1); title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView sub = tv("TOQUE • ARRASTE • PRECISÃO", 12, muted);
        sub.setGravity(Gravity.CENTER); root.addView(sub);

        LinearLayout status = card();
        shizukuStatus = tv("●  SHIZUKU: verificando...", 15, Color.WHITE);
        status.addView(shizukuStatus);
        TextView st2 = tv("Permissão via Shizuku para aplicar apenas ajustes suportados pelo Android.", 12, muted);
        status.addView(st2);
        Button perm = btn("ATIVAR SHIZUKU");
        perm.setOnClickListener(v -> requestShizuku());
        status.addView(perm);
        root.addView(status);

        LinearLayout main = card();
        statusText = tv("STATUS: DESATIVADO", 16, white); statusText.setGravity(Gravity.CENTER);
        main.addView(statusText);
        mainButton = btn("▶  ATIVAR CALIBRAÇÃO");
        mainButton.setOnClickListener(v -> toggleAll());
        main.addView(mainButton);
        root.addView(main);

        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        root.addView(content);
        addCalibration();
        addTouch();
        addResolution();
        addAbout();
    }

    void addCalibration() {
        LinearLayout c=card(); c.addView(tv("🎯  Calibração de Tela (X e Y)",18,white));
        c.addView(tv("Os controles abaixo salvam um perfil de calibração. O Android não oferece uma API universal para deslocar o touch X/Y; o app não finge aplicar isso.",11,muted));
        xVal=tv("Eixo X  +0",14,white); c.addView(xVal);
        xSeek=new SeekBar(this); xSeek.setMax(100); xSeek.setProgress(50); c.addView(xSeek);
        yVal=tv("Eixo Y  +0",14,white); c.addView(yVal);
        ySeek=new SeekBar(this); ySeek.setMax(100); ySeek.setProgress(50); c.addView(ySeek);
        xSeek.setOnSeekBarChangeListener(sb(-50,xVal,"Eixo X"));
        ySeek.setOnSeekBarChangeListener(sb(-50,yVal,"Eixo Y"));
        Button reset=btn("RESTAURAR PADRÃO"); reset.setOnClickListener(v->{xSeek.setProgress(50);ySeek.setProgress(50);});
        c.addView(reset); root.addView(c);
    }
    SeekBar.OnSeekBarChangeListener sb(int off, TextView out, String name) {
        return new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s,int p,boolean f){out.setText(name+"  "+(p+off));}
            public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){}
        };
    }
    void addTouch() {
        LinearLayout c=card(); c.addView(tv("⚡  Toque e Arraste",18,white));
        Switch delay=new Switch(this); delay.setText("Toque 0 Delay"); delay.setTextColor(white); delay.setChecked(prefs.getBoolean("zero",false));
        delay.setOnCheckedChangeListener((b,on)->prefs.edit().putBoolean("zero",on).apply());
        c.addView(delay);
        c.addView(tv("Remove animações do sistema; isso reduz atrasos visuais, mas não altera o hardware do digitizador.",11,muted));
        Switch drag=new Switch(this); drag.setText("Arraste Mais Rápido"); drag.setTextColor(white); drag.setChecked(prefs.getBoolean("drag",false));
        drag.setOnCheckedChangeListener((b,on)->prefs.edit().putBoolean("drag",on).apply()); c.addView(drag);
        c.addView(tv("Modo de jogo",14,white));
        LinearLayout games=new LinearLayout(this); games.setOrientation(LinearLayout.HORIZONTAL);
        for(String s:new String[]{"Free Fire","PUBG","Block Strike","Outros"}) {
            Button g=btn(s); games.addView(g,new LinearLayout.LayoutParams(0,52,1));
        }
        c.addView(games); root.addView(c);
    }
    void addResolution() {
        LinearLayout c=card(); c.addView(tv("📱  Resolução Ideal",18,white));
        resText=tv("Lendo resolução nativa...",14,white); c.addView(resText);
        Button read=btn("CALCULAR RESOLUÇÃO"); read.setOnClickListener(v->readResolution()); c.addView(read);
        c.addView(tv("A recomendação usa a resolução reportada pelo Android. O app não força uma resolução diferente automaticamente.",11,muted));
        root.addView(c); readResolution();
    }
    void addAbout() {
        LinearLayout c=card(); c.addView(tv("♛  KING CALIBRADOR",18,white));
        c.addView(tv("Versão 1.0.0\nPainel de otimização via Shizuku.\nCompatibilidade real depende do fabricante e da versão do Android.",12,muted));
        root.addView(c);
    }

    void requestShizuku() {
        try {
            if(!Shizuku.pingBinder()){ toast("Abra o Shizuku e inicie o serviço primeiro."); return; }
            if(Build.VERSION.SDK_INT >= 23 && Shizuku.checkSelfPermission()!=android.content.pm.PackageManager.PERMISSION_GRANTED)
                Shizuku.requestPermission(REQ);
            else toast("Shizuku já está autorizado.");
        } catch(Exception e){toast("Não foi possível acessar o Shizuku: "+e.getMessage());}
    }
    void updateShizuku() {
        boolean ok=false;
        try{ok=Shizuku.pingBinder();}catch(Exception ignored){}
        shizukuStatus.setText(ok ? "●  SHIZUKU: CONECTADO" : "●  SHIZUKU: NÃO CONECTADO");
        shizukuStatus.setTextColor(ok ? Color.rgb(110,230,130) : Color.rgb(255,120,120));
    }
    boolean hasPerm() {
        try{return Shizuku.pingBinder() && Shizuku.checkSelfPermission()==android.content.pm.PackageManager.PERMISSION_GRANTED;}
        catch(Exception e){return false;}
    }
    String shell(String command) throws Exception {
        if(!hasPerm()) throw new SecurityException("Shizuku sem permissão");
        Process p=Shizuku.newProcess(new String[]{"sh","-c",command},null,null);
        BufferedReader r=new BufferedReader(new InputStreamReader(p.getInputStream()));
        StringBuilder s=new StringBuilder(); String line;
        while((line=r.readLine())!=null)s.append(line).append('\n');
        p.waitFor(); return s.toString().trim();
    }
    void toggleAll() {
        if(!hasPerm()){requestShizuku();return;}
        try {
            boolean active=prefs.getBoolean("active",false);
            if(!active) {
                saveOriginals();
                shell("settings put global window_animation_scale 0.0; settings put global transition_animation_scale 0.0; settings put global animator_duration_scale 0.0");
                // Only request 120 Hz if the device reports a high-refresh mode.
                float hz=getMaxHz();
                if(hz>=119f) shell("settings put system peak_refresh_rate 120.0; settings put system min_refresh_rate 60.0");
                prefs.edit().putBoolean("active",true).apply();
                statusText.setText("STATUS: ATIVADO");
                mainButton.setText("■  DESATIVAR / RESTAURAR");
                toast("Ajustes suportados aplicados.");
            } else {
                restoreOriginals();
                prefs.edit().putBoolean("active",false).apply();
                statusText.setText("STATUS: DESATIVADO");
                mainButton.setText("▶  ATIVAR CALIBRAÇÃO");
                toast("Valores originais restaurados.");
            }
        } catch(Exception e){toast("Falha ao aplicar: "+e.getMessage());}
    }
    void saveOriginals() {
        try {
            prefs.edit()
                .putString("a",shell("settings get global window_animation_scale"))
                .putString("t",shell("settings get global transition_animation_scale"))
                .putString("d",shell("settings get global animator_duration_scale"))
                .putString("peak",shell("settings get system peak_refresh_rate"))
                .putString("min",shell("settings get system min_refresh_rate")).apply();
        } catch(Exception ignored){}
    }
    void restoreOriginals() throws Exception {
        putOrDelete("global","window_animation_scale",prefs.getString("a","null"));
        putOrDelete("global","transition_animation_scale",prefs.getString("t","null"));
        putOrDelete("global","animator_duration_scale",prefs.getString("d","null"));
        putOrDelete("system","peak_refresh_rate",prefs.getString("peak","null"));
        putOrDelete("system","min_refresh_rate",prefs.getString("min","null"));
    }
    void putOrDelete(String ns,String key,String val)throws Exception{
        if(val==null||val.equals("null")||val.isEmpty()) shell("settings delete "+ns+" "+key);
        else shell("settings put "+ns+" "+key+" '"+val.replace("'","")+"'"); 
    }
    float getMaxHz() {
        try {
            float m=0;
            for(android.view.Display.Mode mode:getWindowManager().getDefaultDisplay().getSupportedModes())
                m=Math.max(m,mode.getRefreshRate());
            return m;
        } catch(Exception e){return 60;}
    }
    void readResolution() {
        new Thread(()->{
            String out="";
            try { out=shell("wm size"); }
            catch(Exception e) { 
                android.util.DisplayMetrics dm=new android.util.DisplayMetrics();
                getWindowManager().getDefaultDisplay().getRealMetrics(dm);
                out="Physical/display: "+dm.widthPixels+" x "+dm.heightPixels;
            }
            final String f=out;
            runOnUiThread(()->resText.setText("Resolução detectada:\n"+f+"\nMáxima Hz detectada: "+String.format(Locale.US,"%.0f",getMaxHz())+" Hz"));
        }).start();
    }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override protected void onResume(){super.onResume();updateShizuku();}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);updateShizuku();}
}
