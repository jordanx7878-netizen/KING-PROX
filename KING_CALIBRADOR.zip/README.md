# KING CALIBRADOR
App Android com interface preta/roxa inspirada na referência enviada.

## O que esta versão realmente faz
- Conecta ao Shizuku e solicita autorização.
- Botão Ativar/Desativar.
- Salva e restaura `window_animation_scale`, `transition_animation_scale` e `animator_duration_scale`.
- Detecta os modos de tela e só solicita 120 Hz quando o aparelho reporta um modo de pelo menos 119 Hz.
- Lê a resolução reportada por `wm size`.
- Guarda sliders X/Y como perfil local.

## Limitação importante
Android não possui uma API pública universal para mudar a matriz de transformação/calibração X/Y do digitizador por aplicativo. Portanto, esta versão não finge que os sliders X/Y alteram o hardware do touch. Alterações reais de calibração de touch são específicas do fabricante/kernel e exigem comandos próprios do aparelho.

"Toque 0 delay" também não significa literalmente remover o atraso físico do digitizador. A versão aplica redução de animações do sistema, que reduz atrasos visuais.

## Compilar
Abra o projeto no Android Studio e faça Sync/Build APK.
Dependência Shizuku: `dev.rikka.shizuku:api:13.1.5`.

Antes de usar:
1. Instale/inicie o Shizuku.
2. Abra KING CALIBRADOR.
3. Toque em ATIVAR SHIZUKU.
4. Conceda a permissão.
5. Use ATIVAR CALIBRAÇÃO.

Não force resolução automaticamente: a recomendação usa o modo/resolução que o Android reporta.
